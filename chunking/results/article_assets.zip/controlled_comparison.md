# Controlled Comparison at 3000 char Target

| Config | Strategy | Actual Size | Recall |
|--------|----------|-------------|--------|
| token_3000 | token | 2799 | 0.975 |
| sentence_default | sentence | 3676 | 0.975 |
| sentence_3000 | sentence | 8150 | 0.950 |
| recursive_3000 | recursive | 2295 | 0.900 |
| semantic_3000 | semantic | 1117 | 0.718 |