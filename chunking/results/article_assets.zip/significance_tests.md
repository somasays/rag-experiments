# Statistical Significance Tests

## Fisher's Exact Test Results

| Comparison | Recall A | Recall B | p-value | Cohen's h | Effect |
|------------|----------|----------|---------|-----------|--------|
| token_3000 vs sentence_3000 | 0.97 | 0.97 | 1.0000  | 0.00 | Negligible |
| token_default vs sentence_default | 0.80 | 0.97 | 0.0289 ✓ | 0.61 | Medium |
| token_3000 vs recursive_3000 | 0.97 | 0.93 | 0.6153  | 0.24 | Small |
| recursive_default vs sentence_default | 0.75 | 0.97 | 0.0069 ✓ | 0.73 | Medium |

## Interpretation

- **p < 0.05**: Statistically significant difference
- **Cohen's h > 0.8**: Large practical effect
- **Cohen's h 0.5-0.8**: Medium practical effect
- **Cohen's h 0.2-0.5**: Small practical effect