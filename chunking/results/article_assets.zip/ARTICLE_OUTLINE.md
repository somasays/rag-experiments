# The Dirty Secret of RAG Chunking

> Why Sentence Chunking "Wins" Every Benchmark

## Hook (Problem Statement)

"Everyone says sentence chunking is best for RAG. We ran 30 experiments and found something surprising: the 'winning' strategy is cheating."

## The Experiment Setup

- **4 experiments**, 30 configurations total
- **2 datasets**: HotpotQA (3.5K-8K char docs) + Natural Questions (96K char docs)
- **4 strategies**: Token, Sentence, Recursive, Semantic chunking
- **Evaluation**: RAGAS with context_recall as primary metric
- **LLM**: Ollama mistral:7b for generation, text-embedding-3-small for embeddings

## The "Winning" Strategy (Naive View)

[Insert basic results table showing sentence chunking dominates]

"Looking at this data, the conclusion seems obvious: use sentence chunking. Case closed, right?"

"Not so fast."

## The Twist: Looking at Actual Chunk Sizes

[Insert Money Chart: chunk_size_vs_recall.png]

"When we plot actual chunk sizes against recall, a pattern emerges. But wait—why are sentence chunks so much larger than the others?"

### The Lie Table

[Insert requested vs actual chunk size table]

"LlamaIndex's SentenceSplitter is ignoring our chunk_size parameter. When we ask for 1024-character chunks, it produces 3677-character chunks—3.6x larger than requested."

"This isn't a bug. It's documented behavior. But it means every benchmark comparing 'sentence chunking' to other strategies at 'the same chunk size' is fundamentally flawed."

## The Controlled Experiment

"What happens when we actually control for chunk size?"

[Insert controlled_comparison.png]

"At the ~3000 character target:"
- **token_3000**: 2800 chars → 97.5% recall
- **recursive_3000**: 2295 chars → 90.0% recall
- **sentence_3000**: 8150 chars → 95.0% recall (STILL cheating!)

"When chunk sizes are similar, token chunking actually beats sentence chunking."

## The Real Finding

**Chunk SIZE is the dominant factor, not chunking STRATEGY.**

- HotpotQA correlation: r = 0.74
- Natural Questions correlation: r = 0.92

"The winning strategy isn't sentence, token, or semantic. It's bigger chunks."

## Why This Matters

1. **Most RAG tutorials are giving wrong advice** - They're comparing strategies with confounded chunk sizes
2. **Benchmarks are misleading** - Without controlling for chunk size, comparisons are meaningless
3. **Your production system might be misconfigured** - If you set chunk_size=1024 with sentence chunking, you're actually getting ~3500+ char chunks

## Practical Recommendations

| Use Case | Recommendation |
|----------|----------------|
| Maximum recall | Token or Sentence with 2500-3500 char chunks |
| Controlled experiments | Token or Recursive (respect size config) |
| Content-driven boundaries | Semantic (but accept ~1000 char chunks) |
| Long documents (50K+) | Sentence with 3000+ char target |

## The Deeper Insight

"Chunking strategy is like a UI layer. It affects where the boundaries land, but the real knob is chunk size."

"If you want 95%+ context recall, the recipe is simple: use larger chunks. How you split them is secondary."

## Conclusion

"Don't trust the benchmarks. Trust the data."

"Next time you see a blog post claiming 'X chunking strategy is best,' ask one question: did they control for chunk size?"

---

## Appendix: Full Results

[Link to detailed results and analysis report]

---

*Generated from 30 experiment configurations across 2 datasets using RAGAS evaluation.*
